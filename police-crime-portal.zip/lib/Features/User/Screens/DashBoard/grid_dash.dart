import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:public_emergency_app/Features/User/Screens/PoliceOptions/police_options.dart';

class GridDashboard extends StatelessWidget {
  Items item1 = Items(
      title: "Police",
      subtitle: "Emergency Police ",
      event: "",
      img: "assets/logos/policeman.png");

  GridDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    List<Items> myList = [item1];
    var color = 0xff2471A3;
    double itemWidth = MediaQuery.of(context).size.width * 0.7;
    double itemHeight = MediaQuery.of(context).size.height * 0.4;
    return GridView.count(
        padding: const EdgeInsets.only(left: 6, right: 6, top: 10),
        crossAxisCount: 1,
        crossAxisSpacing: 18,
        mainAxisSpacing: 18,
        childAspectRatio: (itemWidth / itemHeight),
        children: myList.map((data) {
          return GestureDetector(
            onTap: () {
              Get.to(() => const PoliceOptions());
            },
            child: Container(
              width: itemWidth,
              height: itemHeight,
              decoration: BoxDecoration(
                  color: Color(color), borderRadius: BorderRadius.circular(10)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: 200, // Adjusted image height
                    child: Image.asset(
                      data.img,
                      width: 200, // Adjusted image width
                    ),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Text(
                    data.title,
                    style: GoogleFonts.openSans(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Text(
                    data.subtitle,
                    style: GoogleFonts.openSans(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontSize: 21,
                            fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(
                    height: 14,
                  ),
                  Text(
                    data.event,
                    style: GoogleFonts.openSans(
                        textStyle: const TextStyle(
                            color: Colors.white70,
                            fontSize: 11,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          );
        }).toList());
  }
}

class Items {
  String title;
  String subtitle;
  String event;
  String img;
  Items(
      {required this.title,
      required this.subtitle,
      required this.event,
      required this.img});
}
