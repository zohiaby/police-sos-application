import 'dart:math';

class Keys{
  final int appId=2138022557;
  final String appSign="8bc0ca30f28a7cf4c946aaa15537731cc358f7b4336c2096995c5f6392dd224d";
  final String userId=Random().nextInt(100000).toString();
}