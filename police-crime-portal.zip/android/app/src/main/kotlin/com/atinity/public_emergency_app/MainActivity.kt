package com.atinity.public_emergency_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
